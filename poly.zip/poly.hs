import Data.List
import System.IO
import Debug.Trace

-- Joe Gilbert 
-- COMP 3200 
-- 12/4/2019


-- To get this to work, you'll need to download the Haskell source code and WinGHCI at:
-- https://www.haskell.org/downloads/
-- Follow the instructions listed on the download page.
-- Then, put the code somewhere where you know where it is.
-- Wherever you put this program, you also need to put the input file:
-- polyInput.txt
-- They must be in the same directory.
-- Then, run WinGHCI. Click on the button with the picture of an opened file on it.
-- Select this source code file.
-- Then hit the big red arrow button at the top.
-- The program should automatically run and output to the stdout as soon as you press the red arrow.
-- To stop the program's execution at any time, press the the gray pause button.   


{-
10
6 7 8 9 10 11 12 13 14 15
1000
5
3 4 13 36 124
1
0
-}

-- The main function that will run when the program is compiled and "main" is put into the command prompt.
-- First, we read each line of the input file.
-- Since each entry is 3 lines long, we can do some sneaky stuff.
-- We can take the file 3 lines at a time by 
-- getting the number of lines, then subtracting 1 (the end line)
-- and then put each line into a data structure for easy access.
-- We can put all those data structures into a list 
-- and then process each one at a time.
-- We convert the lines into lists of 3 lines each.
-- Now that we have a list of string lists, we take each of those lists and 
-- convert them into tuples that we can then evaluate.
-- Now that we have a list of lists of tuples, we find the polypolygonals of each list of tuples.
-- We then turn the resulting polypolygonals back into strings and format them appropriately for the output.

main = do {
    inputFile <- openFile "polyInput.txt" ReadMode;
    fileContents <- hGetContents inputFile;
    let linesOfFile = init (lines fileContents)
        emptyStringListOne = []::[[String]]
        emptyStringListTwo = []::[[String]]
        emptyTupleListOne = []::[[(Int, Int, Int)]]
        emptyTupleListTwo = []::[[(Int, [Int])]]
        entryList = convertLinesToThrees 0 linesOfFile emptyStringListOne 
        convertedTuples = convertThreesToTuples entryList
        initialTuples = createAllTuples 0 convertedTuples emptyTupleListOne
        initialPolys = getAllPolys 5 0 emptyTupleListTwo initialTuples
        allStrings = convertAllResultsToSting 0 initialPolys emptyStringListTwo
        in (mapM_.mapM_) putStrLn allStrings
}


-- Function to take the list of lines and put every 3 lines into their own list.
-- Input 0, list of lines, list that we want to add entries to.
convertLinesToThrees :: Int -> [String] -> [[String]] -> [[String]];
convertLinesToThrees pointer lineList entryList = do {
    if pointer == (length lineList)
        then entryList;
    else let pointerOne = pointer + 1
             pointerTwo = pointer + 2
             pointerThree = pointer + 3
             newEntry = [lineList!!pointer, lineList!!pointerOne, lineList!!pointerTwo]
             in convertLinesToThrees pointerThree lineList (entryList ++ [newEntry]);
}



-- We do this using the convertThreeToIntTuple method mapped onto the string list.
convertThreesToTuples :: [[String]] -> [(Int, [Int], Int)];
convertThreesToTuples stringList = map (convertThreeToIntTuple) stringList;


-- Function that takes an entry and converts its strings into usable data.
-- Convert the first line to be an int.  This is n.
-- Convert the second line to be a list of ints. This is the index list containing each k to make a kgon out of.
-- Convert the third line to be an int.  This is the start.
convertThreeToIntTuple :: [String] -> (Int, [Int], Int);
convertThreeToIntTuple entry = ((read (entry !! 0) :: Int), (getIndexListFromLine (entry !! 1)), (read (entry !! 2) :: Int));



-- Now that we have a list of lists of tuples, we need to find the polypolygonals of each list of tuples.
-- We call it initially on the list of tuples with the limit 5, and an empty list = [(Int, [Int])].
-- Call this with initial count of 0, the tuplelist, and an empty list of lists of tuples.
createAllTuples :: Int -> [(Int, [Int], Int)] -> [[(Int, Int, Int)]] -> [[(Int, Int, Int)]];
createAllTuples count tupleList listSoFar = do {
    if count == (length tupleList)
        then listSoFar
    else let k = map (createListOfTuples (getStartOfTuple (tupleList !! count))) [(getListFromTuple (tupleList !! count))]
             in createAllTuples (count + 1) tupleList (listSoFar ++ k);
}

-- Plural function of findPolygonals.
-- Call this with 5, 0, empty list, tuplelist.
-- There is a problem here with inputting less than or equal to 5 indices
getAllPolys :: Int -> Int -> [[(Int, [Int])]] -> [[(Int, Int, Int)]] -> [[(Int, [Int])]];
getAllPolys limit count polypolygonalList tupleList = do {
    if count == length tupleList
        then polypolygonalList;
        else let tup = tupleList !! count
                 poly = []::[(Int, [Int])]
                 result = findPolygonals limit poly tup
                 polyPoly = polypolygonalList ++ [result]
                 in getAllPolys limit (count + 1) polyPoly tupleList;
}



-- Function that looks at all the tuples in a list.
-- Finds the smallest tuple in the list.
-- Then compares the smallest to the other tuples in the list to check for equality.
-- If 2 values are the same, it creates a new tuple with that value and the indices it comes from.
-- If there are no matches, increment the smallest of all the values by its increment.
-- It continues until we have 5 entries in the list of tuples of matches.
-- Takes in the number of polypolygonals we want (5), the list of polypolygonals, the list of tuples.
-- Initially the list of polypolygonals will be empty (i.e. []). 
findPolygonals :: Int -> [(Int, [Int])] -> [(Int, Int, Int)] -> [(Int, [Int])];
findPolygonals limit polygonalList tupleList = do {
    if length polygonalList < limit
        then if null (findMatchList (getMinTuple 0 tupleList (tupleList !! 0)) tupleList)
                 then findPolygonals limit polygonalList (convertMinTupleList tupleList (getMinTuple 0 tupleList (tupleList !! 0)))
             else let minTuple = getMinTuple 0 tupleList (tupleList !! 0)
                      matches = findMatchList minTuple tupleList
                      pol = createInitialKGon minTuple matches
                      in findPolygonals limit (nub (polygonalList ++ [pol])) (convertMinTupleList tupleList minTuple)  
    else polygonalList;
}




-- Function that creates a list of matching tuples including the min.
findMatchList :: (Int, Int, Int) -> [(Int, Int, Int)] -> [(Int, Int, Int)];
findMatchList minTuple tupleList = filter (compareTuplesSame minTuple) (filter (compareValuesInTuplesEqual minTuple) tupleList); 


-- Function to create the list of tuples we need to compare the values of.
createListOfTuples :: Int -> [Int] -> [(Int, Int, Int)];
createListOfTuples start indexList = map (findFirstValue start) (map createInitialTuple indexList);

convertAllResultsToSting :: Int -> [[(Int, [Int])]] -> [[String]] -> [[String]];
convertAllResultsToSting count solutionList finalStringList = do {
    if count == length solutionList
        then finalStringList
        else let solution = solutionList !! count
                 finalString = convertPolypolysToStrings solution 
                 in convertAllResultsToSting (count + 1) solutionList (finalStringList ++ [finalString])
}



-- This function here takes the entire list of solutions and converts it to a list of strings.
convertPolypolysToStrings :: [(Int, [Int])] -> [String];
convertPolypolysToStrings solutionList = map (convertPolypolyToString) solutionList;

-- Function that converts a single solution tuple to a string.
convertPolypolyToString :: (Int, [Int]) -> String;
convertPolypolyToString (value, kList) = do {
    let firstStr = (show value) ++ ": "
        secondStr = intercalate " " (map (show) kList)
        in firstStr ++ secondStr
}


-- Function to find the next number in the list.
nextNumberInList :: (Int, Int, Int) -> (Int, Int, Int);
nextNumberInList (index, currentItem, currentIncrement) = do {
    let setter = setIncrement index currentIncrement in (index, currentItem + setter, setter);
}

-- Function to set up the initial increment of a k-gonal list.
-- Since we need to increase the number we increment the list
-- value by each time by k-2, this is necessary.
setIncrement :: Int -> Int -> Int;
setIncrement index currentIncrementValue = currentIncrementValue + (index - 2);


-- Function to create the initial tuples for each k-gon.
-- Take s, then k.
createInitialTuple :: Int -> (Int, Int, Int);
createInitialTuple index = (index, index, index - 1);



-- Function to find the tuple with the smallest value in a list of tuples.
-- We feed it the list of tuples, and the smallest tuple so far. 
-- Then, we look at each tuple two at a time to see if any are smaller. 
-- When the counter is zero, we stop, and the output is the smallest.
-- Initially, we'd call this function with count being 0.
getMinTuple :: Int -> [(Int, Int, Int)] -> (Int, Int, Int) -> (Int, Int, Int);
getMinTuple count tupleList currentSmallest = do {
    if count == ((length tupleList) - 1)
        then compareTuplesSmaller currentSmallest (tupleList !! count );
    else getMinTuple (count + 1) tupleList (compareTuplesSmaller currentSmallest (tupleList !! (count + 1)));  
}



-- Function to find first value of the list.
-- Call this initially with s k k k-1 and it will work perfectly.
-- For example, we call findFirstValue 500 (5, 5, 4) to find the first pentagonal number at s = 500.
-- The correct result should be (5, 532, 55).
findFirstValue :: Int -> (Int, Int, Int) -> (Int, Int, Int);
findFirstValue start (index, currentValue, currentIncrementValue) = do {
    if start <= 1
        then (index, start, (index - 1));
    else if start <= currentValue  
            then (index, currentValue, currentIncrementValue); 
         else let setter = setIncrement index currentIncrementValue
                  in findFirstValue start (index, (currentValue + setter), setter)
}


-- Creates the initial K Gon for the match.
-- Assumes the values are equal.
createInitialKGon :: (Int, Int, Int) -> [(Int, Int, Int)] -> (Int, [Int]);
createInitialKGon (indexOne, valueOne, incrementOne) matches = (valueOne, (map getIndexOfTuple matches) ++ [indexOne]);





-- Function to take the min of the list and increment it.
-- Returns the list with the replaced min.
convertMinTupleList :: [(Int, Int, Int)] -> (Int, Int, Int) -> [(Int, Int, Int)];
convertMinTupleList tupleList minTuple = (filter (compareValuesInTuplesNotEqual minTuple) tupleList) ++ [nextNumberInList minTuple];


-- Function to get the list of indices from the second line of an entry read in from the input file.
getIndexListFromLine :: String -> [Int];
getIndexListFromLine indexLine = map (read::String->Int) (words indexLine);

-- Function to get index from a tuple.
getIndexOfTuple :: (Int, Int, Int) -> Int;
getIndexOfTuple (index, _, _) = index;

-- Gets the list from the tuple
getListFromTuple :: (Int, [Int], Int) -> [Int];
getListFromTuple (_, kList, _) = kList;

-- Function to get value from a tuple.
getValueOfTuple :: (Int, Int, Int) -> Int;
getValueOfTuple (_, value, _) = value;

-- Function to get value from a tuple.
getStartOfTuple :: (Int, [Int], Int) -> Int;
getStartOfTuple (_, _, start) = start;

-- Function to find smallest values in 2 tuples.
compareTuplesSmaller :: (Int, Int, Int) -> (Int, Int, Int) -> (Int, Int, Int);
compareTuplesSmaller (indexOne, valueOne, incrementOne) (indexTwo, valueTwo, incrementTwo) 
    | valueOne < valueTwo = (indexOne, valueOne, incrementOne)
    | valueOne > valueTwo = (indexTwo, valueTwo, incrementTwo)
    | otherwise = (indexOne, valueOne, incrementOne)

-- Function to compare the values of two tuples to test for equivalence.
compareValuesInTuplesEqual :: (Int, Int, Int) -> (Int, Int, Int) -> Bool;
compareValuesInTuplesEqual (indexOne, valueOne, incrementOne) (indexTwo, valueTwo, incrementTwo) = do {
    if valueOne == valueTwo
        then True;
    else False;
}

-- Function to check if the tuples are the exact same.
compareTuplesSame :: (Int, Int, Int) -> (Int, Int, Int) -> Bool;
compareTuplesSame (indexOne, valueOne, incrementOne) (indexTwo, valueTwo, incrementTwo) = do {
    if indexOne == indexTwo && valueOne == valueTwo && incrementOne == incrementTwo
        then False;
    else True;
}

-- Function to compare the values of two tuples to test for equivalence.
compareValuesInTuplesNotEqual :: (Int, Int, Int) -> (Int, Int, Int) -> Bool;
compareValuesInTuplesNotEqual (indexOne, valueOne, incrementOne) (indexTwo, valueTwo, incrementTwo) = do {
    if valueOne == valueTwo
        then False;
    else True;
}

